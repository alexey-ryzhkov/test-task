import boto3
import random
import json

def lambda_handler(event, context):
    # Connecting to the table
    client = boto3.resource("dynamodb")
    table = client.Table("words")

    # print(table.item_count)
    # We could have used table.item_count variable to provide the boundaries for
    # our random value if it would have been updated dynamically. Unfortunately,
    # row count in AWS DynamoDB is updated every 6 hours, so this is not usable for
    # our test case. We need to count amount of items manually via scanning entire table,
    # even though this is not applicable for real tables with millions of records.

    # Counting items in the table
    count=0
    table_scan=table.scan()['Items']
    for item in table_scan:
        count += 1

    # Printing random value from range
    index=random.randint(0, count-1)
    word = table.scan()['Items'][index]['word']
    print(word)

    #return word
    return {
        'statusCode': 200,
        'body': json.dumps(word)
    }
